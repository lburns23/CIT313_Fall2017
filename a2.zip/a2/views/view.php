<!DOCTYPE html>
	<html>
	<head>
		<title>Fisher Price - My First Model View Controller</title>
	</head>
	<body>
		<h1>Hello From My View!</h1>
		<ul>
		<?php
		echo "<li>User ID: ".$userID."</li><li> First Name: ".$firstname."</li><li>Last Name: ".$lastname."</li><li>Email: ".$email."</li><li>Role: ".$role."</li>";
		?>
		</ul>
	</body>

		
