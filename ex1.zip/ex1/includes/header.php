<?php
echo "<p>Exercise 1 PHP Review</p>";
?>