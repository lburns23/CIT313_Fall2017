<?php
echo "<p>Copyright &copy; 2017</p>";
?>