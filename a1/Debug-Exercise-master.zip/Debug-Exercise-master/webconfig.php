<?php

define('ABSOLUTE_PATH', '/home/burns23/htdocs/a1/Debug-Exercise-master/');
define('URL_ROOT', '\a1\Debug-Exercise-master');