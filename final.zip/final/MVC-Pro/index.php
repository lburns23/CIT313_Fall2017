<?php

// Display errors in production mode
ini_set('display_errors', 0);

// let's get started
require 'application/router.php';


