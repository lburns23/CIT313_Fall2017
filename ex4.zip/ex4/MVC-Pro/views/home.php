<?php include('elements/header.php');?>
<div class="container">
	<div class="page-header">
    <h1> Hello From the View</h1>
  </div>
</div>
<?php include('elements/footer.php');?>
